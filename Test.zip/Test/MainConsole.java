import GameLogic.*;
import GameLogic.Pieces.*;
import java.util.Scanner;

public class MainConsole {
    public static void main(String[] args) {
        Board board = new Board();
        AI ai = new AI();
        Scanner scanner = new Scanner(System.in);
        
        // QUY ƯỚC: Người chơi là ĐỎ (DOWN - Chữ Hoa), Máy là ĐEN (UP - chữ thường)
        // Đỏ đi trước
        Piece.Side humanSide = Piece.Side.DOWN;
        Piece.Side aiSide = Piece.Side.UP;
        boolean isHumanTurn = true; 

        while (true) {
            printBoard(board);
            
            if (isHumanTurn) {
                // --- LƯỢT NGƯỜI ---
                System.out.println(">> Lượt BẠN (Đỏ). Nhập tọa độ (x1 y1 x2 y2): ");
                String input = scanner.nextLine();
                if (input.equals("exit")) break;
                
                try {
                    String[] parts = input.split(" ");
                    int x1 = Integer.parseInt(parts[0]);
                    int y1 = Integer.parseInt(parts[1]);
                    int x2 = Integer.parseInt(parts[2]);
                    int y2 = Integer.parseInt(parts[3]);
                    Move move = new Move(x1, y1, x2, y2);

                    // Check sơ bộ
                    Piece p = board.getPiece(x1, y1);
                    if (p == null || p.getSide() != humanSide) {
                        System.out.println("LỖI: Chọn sai quân!");
                        continue;
                    }

                    if (board.isValidMove(move)) {
                        board.executeMove(move);
                        isHumanTurn = false; // Chuyển lượt cho máy
                    } else {
                        System.out.println("LỖI: Nước đi sai luật!");
                    }
                } catch (Exception e) {
                    System.out.println("Lỗi cú pháp! Nhập lại.");
                }

            } else {
                // --- LƯỢT MÁY (AI) ---
                System.out.println(">> Máy đang suy nghĩ...");
                Move bestMove = ai.findBestMove(board, aiSide);
                
                if (bestMove != null) {
                    board.executeMove(bestMove);
                    System.out.println(">> Máy đã đi: " + bestMove.toString());
                    isHumanTurn = true; // Chuyển lượt lại cho người
                } else {
                    System.out.println(">> Máy hết nước đi! BẠN THẮNG!");
                    break;
                }
            }
        }
    }
    
    // (Hàm printBoard giữ nguyên như cũ)
    public static void printBoard(Board board) {
        // ... Code vẽ bàn cờ của bạn ...
        // (Copy lại hàm printBoard từ câu trả lời trước)
        System.out.println("\n   0 1 2 3 4 5 6 7 8  (X)");
        System.out.println("  -------------------");
        for (int y = 0; y < Board.BOARD_HEIGHT; y++) {
            System.out.print(y + "| ");
            for (int x = 0; x < Board.BOARD_WIDTH; x++) {
                Piece p = board.getPiece(x, y);
                String symbol = ".";
                if(p != null) {
                    symbol = p.getType().substring(0, 1);
                    if(p.getType().equals("Chariot")) symbol = "R"; // Xe
                    if(p.getType().equals("Horse")) symbol = "H";   // Mã
                    if(p.getType().equals("Cannon")) symbol = "C";  // Pháo
                    if(p.getType().equals("Soldier")) symbol = "S"; // Tốt
                    if(p.getType().equals("General")) symbol = "K"; // Tướng
                    if(p.getType().equals("Elephant")) symbol = "E"; // Tượng
                    if(p.getType().equals("Guard")) symbol = "A";   // Sĩ
                    
                    if(p.getSide() == Piece.Side.DOWN) symbol = symbol.toUpperCase();
                    else symbol = symbol.toLowerCase();
                }
                System.out.print(symbol + " ");
            }
            System.out.println("|" + y);
        }
    }
}