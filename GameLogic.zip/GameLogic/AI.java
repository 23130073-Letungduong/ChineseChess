package GameLogic;

import GameLogic.Pieces.Piece;
import java.util.List;

public class AI {
    
    // Độ sâu tìm kiếm: 3 nước (Càng cao càng giỏi nhưng càng chậm)
    private static final int MAX_DEPTH = 3;

    // Hàm trả về nước đi tốt nhất
    public Move findBestMove(Board board, Piece.Side aiSide) {
        int bestVal = Integer.MIN_VALUE;
        Move bestMove = null;
        
        // Lấy tất cả nước đi có thể của AI
        List<Move> allMoves = board.generateMoves(aiSide);

        for (Move move : allMoves) {
            board.executeMove(move); // 1. Đi thử
            
            // 2. Tính điểm nước đi này bằng Minimax
            int moveVal = minimax(board, MAX_DEPTH - 1, Integer.MIN_VALUE, Integer.MAX_VALUE, false, aiSide);
            
            board.undoMove(move);    // 3. Hoàn tác (Backtracking)

            // 4. Nếu điểm cao hơn nước tốt nhất hiện tại thì cập nhật
            if (moveVal > bestVal) {
                bestVal = moveVal;
                bestMove = move;
            }
        }
        return bestMove;
    }

    //Minimax + Alpha Beta
    private int minimax(Board board, int depth, int alpha, int beta, boolean isMaximizing, Piece.Side aiSide) {
        // Điều kiện dừng: Hết độ sâu
        if (depth == 0) {
            return evaluateBoard(board, aiSide);
        }

        Piece.Side currentSide = isMaximizing ? aiSide : (aiSide == Piece.Side.UP ? Piece.Side.DOWN : Piece.Side.UP);
        List<Move> moves = board.generateMoves(currentSide);

        if (isMaximizing) { // Lượt của AI (Muốn điểm cao nhất)
            int maxEval = Integer.MIN_VALUE;
            for (Move move : moves) {
                board.executeMove(move);
                int eval = minimax(board, depth - 1, alpha, beta, false, aiSide);
                board.undoMove(move);
                
                maxEval = Math.max(maxEval, eval);
                alpha = Math.max(alpha, eval);
                if (beta <= alpha) break; // Cắt tỉa nhánh thừa
            }
            return maxEval;
        } else { // Lượt của Người chơi (Sẽ đi nước làm AI khổ nhất -> Điểm thấp nhất)
            int minEval = Integer.MAX_VALUE;
            for (Move move : moves) {
                board.executeMove(move);
                int eval = minimax(board, depth - 1, alpha, beta, true, aiSide);
                board.undoMove(move);
                
                minEval = Math.min(minEval, eval);
                beta = Math.min(beta, eval);
                if (beta <= alpha) break; // Cắt tỉa
            }
            return minEval;
        }
    }

    // Hàm đánh giá thế cờ (Heuristic)
    private int evaluateBoard(Board board, Piece.Side aiSide) {
        int score = 0;
        for (Piece p : board.getAllPieces()) {
            int value = getPieceValue(p);
            if (p.getSide() == aiSide) {
                score += value; // Quân mình cộng điểm
            } else {
                score -= value; // Quân địch trừ điểm
            }
        }
        return score;
    }

    // Bảng điểm giá trị quân cờ
    private int getPieceValue(Piece p) {
        switch (p.getType()) {
            case "General": return 10000; // Tướng là vô giá
            case "Chariot": return 90;    // Xe mạnh nhất
            case "Cannon":  return 45;    // Pháo
            case "Horse":   return 40;    // Mã
            case "Elephant":return 20;    // Tượng
            case "Guard":   return 20;    // Sĩ
            case "Soldier": return 10;    // Tốt (cơ bản)
            default: return 0;
        }
    }
}
